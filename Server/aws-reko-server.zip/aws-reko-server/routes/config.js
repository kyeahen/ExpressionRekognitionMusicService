module.exports.collectionName = "aws-reko-server";
module.exports.region = "ap-northeast-2";